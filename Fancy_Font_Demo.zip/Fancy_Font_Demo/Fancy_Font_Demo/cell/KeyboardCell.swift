//
//  Fontcell.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 26/04/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

class KeyboardCell: UITableViewCell {

    // MARK : PROPERTIES
    
    @IBOutlet weak var ViewMain: UIView!
    @IBOutlet weak var ViewImageView: UIView!
    @IBOutlet weak var ImageView: UIImageView!
    @IBOutlet weak var ImageKeyboard: UIImageView!
    @IBOutlet var btnAllTextCollection: [UIButton]!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
