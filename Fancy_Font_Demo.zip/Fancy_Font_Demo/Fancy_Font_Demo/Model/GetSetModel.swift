//  GetSetModel.swift
//  CalcVault
//
//  Created by Setblue on 20/07/18.
//  Copyright © 2018 Setblue. All rights reserved.
//

import UIKit

// STATIC KEY
let UD_SERVICE_URL                              = "UD_SERVICE_URL"
let UD_UDID                                     = "UD_UDID"
let UD_SELECTED_THEME                           = "UD_SELECTED_THEME"
let UD_ALL_CUSTOME_FONT                         = "ALL_CUSTOME_FONT"
let UD_ALL_CUSTOME_KEYBOARD                     = "ALL_CUSTOME_KEYBOARD"
let UD_ALL_TEXT_ART                             = "ALL_TEXT_ART"
let UD_ALL_OWN_TEXT                             = "ALL_OWN_TEXT"
let UD_SELECTED_FONT_KEYBOARD                   = "SELECTED_FONT_KEYBOARD"

let UD_ADREMOVED                                = "UD_adRemoved"
let UD_FEAREMOVED                               = "UD_feaRemoved"
let UD_KEY_UDID                                 = "UD_Device_Unique_Key"
let UD_KEY_ACCESSTOKEN                          = "Access TokenKey"
let UD_KEY_APPUSER                              = "App User"
let UD_KEYBOARD_SETTING                         = "UD_KEYBOARD_SETTING"
let ID_EXTENTION_KEYBOARD                       = "group.V2Ideas.FancyFont"

class GetSetModel: NSObject {

    class func setStringValueToUserDefaults(strValue: String, ForKey: String) {
        UserDefaults.standard.setValue(strValue, forKey:ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getStringValueFromUserDefaults(_ ForKey: String) -> String {
        return UserDefaults.standard.value(forKey: ForKey) as! String
    }
    
    class func setIntegerValueToUserDefaults(intValue: Int, ForKey: String) {
        UserDefaults.standard.setValue(intValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getIntegerValueFromUserDefaults(_ forKey: String) -> Int {
        return (UserDefaults.standard.value(forKey: forKey) as! Int)
    }
    
    class func setBoolValueToUserDefaults(boolValue: Bool, ForKey: String) {
        UserDefaults.standard.setValue(boolValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getBooleanValueFromUserDefaults(_ ForKey: String) -> Bool {
        return (UserDefaults.standard.value(forKey: ForKey) as! Bool)
    }
    
    class func setObjectToUserDefaults(objValue: typeAliasDictionary, ForKey: String) {
        UserDefaults.standard.setValue(objValue, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    
    class func getObjectFromUserDefaults(_ ForKey: String) -> typeAliasDictionary {
        return UserDefaults.standard.object(forKey: ForKey) as! typeAliasDictionary
    }
    
    class func setCustomObjToUserDefaultsInSystem(CustomeObj: AnyObject, ForKey CustomeObjKey: String) {
        let defaults = UserDefaults.standard
        let encodedData = NSKeyedArchiver.archivedData(withRootObject: CustomeObj)
        defaults.set(encodedData, forKey: CustomeObjKey)
        defaults.synchronize()
        
    }
    class func getCustomObjFromUserDefaultsInSystem_ForKey(CustomeObjKey: String) -> AnyObject {
        let defaults = UserDefaults.standard
        let decoded  = defaults.object(forKey: CustomeObjKey) as! NSData
        let decodedTeams = NSKeyedUnarchiver.unarchiveObject(with: decoded as Data)! as AnyObject
        return decodedTeams
    }
    
    class func setCustomObjToUserDefaultsInExtenion(CustomeObj: AnyObject, ForKey CustomeObjKey: String) {
        let defaults1 = UserDefaults.init(suiteName: ID_EXTENTION_KEYBOARD)
        let encodedData = NSKeyedArchiver.archivedData(withRootObject: CustomeObj)
        defaults1?.set(encodedData, forKey: CustomeObjKey)
        defaults1?.synchronize()
    }
    class func getCustomObjFromUserDefaultsInExtenion_ForKey(CustomeObjKey: String) -> AnyObject {
        let defaults1 = UserDefaults.init(suiteName: ID_EXTENTION_KEYBOARD)
        let decoded  = defaults1!.object(forKey: CustomeObjKey) as! NSData
        let decodedTeams = NSKeyedUnarchiver.unarchiveObject(with: decoded as Data)! as AnyObject
        return decodedTeams
    }
    class func setArrayToUserDefaults(arrayData: [typeAliasDictionary], ForKey: String) {
        UserDefaults.standard.setValue(arrayData, forKey: ForKey)
        UserDefaults.standard.synchronize()
    }
    class func getArrayFromUserDefaults(_ ForKey: String) -> [typeAliasDictionary] {
        return UserDefaults.standard.object(forKey: ForKey) as! [typeAliasDictionary]
    }
    
    class func removeObjectForKey(objectKey: String) {
        UserDefaults.standard.removeObject(forKey: objectKey)
        UserDefaults.standard.setValue(nil, forKey: objectKey)
        UserDefaults.standard.synchronize()
    }
    
    class func removeAllKeyFromDefault(){
        UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        if let bundle = Bundle.main.bundleIdentifier { UserDefaults.standard.removePersistentDomain(forName: bundle) }
        UserDefaults.standard.synchronize()
    }
    
    class func iskeyAlreadyExist(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
        
    }
}
