//
//  MessageFile.swift
//
//  Created by Setblue on 15/11/17.
//  Copyright © 2017 CrudePost. All rights reserved.
//

import Foundation

let SOMETHING_WRONG                             = "Something Went wrong, Please trye again"
let MSG_SOMETHING_WROG                          = "Something went wrong"

let MSG_TXT_QUESTION_ANSWER                     = "Enter Answer First!!!"
let MSG_TXT_QUESTION_ANSWER_VALID               = "Enter Valid Answer!!!"
let MSG_TXT_PASSCODE_NEW                        = "Enter new password"
let MSG_TXT_PASSCODE                            = "Enter password"
let MSG_TXT_PASSCODE_CONFIRM                    = "Enter confirm password"
let MSG_TXT_EMAIL                               = "Enter email address"
let MSG_TXT_EMAIL_VALID                         = "Enter valid email"
let MSG_TXT_PASSCODE_OLD                        = "Enter current password"
let MSG_TXT_NEW_CONFIRM_PASSWORD_SAME           = "New password and retype password must be same"
let MSG_TXT_NOTE_TEXT                           = "Enter Note Text"
let MSG_TXT_NOTE_SAVED                          = "Your Note is saved"
let MSG_TXT_UPDATE_NOTE                         = "Your Note is Updated"

let MSG_TXT_CREDETIAL_WEBSITE                   = "Enter Website"
let MSG_TXT_CREDETIAL_USERNAME                  = "Enter Username"

let MSG_QUE_LOGOUT                              = "Are you sure you want to logout ?"

let MSG_QUE_SKIP_ASSIGNMENT                     = "You are only allowed to skip 3 assignments a day. Are you sure you would like to skip this assignment ?"

let MSG_QUE_CANCEL_ASIGNMENT                    = "Are you sure you would like to cancel your assignment ?"
let MSG_QUE_CANCEL_SUBSTITUTE                   = "Are you sure you would like to cancel your substitute ?"

let MSG_QUE_CHECKOUT                            = "Are you sure you would like to clock out of your assignment ?"
