//
//  ViewController.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 24/04/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

