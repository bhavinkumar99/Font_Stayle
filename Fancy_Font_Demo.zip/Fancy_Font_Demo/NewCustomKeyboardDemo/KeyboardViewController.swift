//
//  KeyboardViewController.swift
//  NewCustomKeyboardDemo
//
//  Created by Setblue's iMac on 29/04/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

enum Selected_Option {
    case FONT_LIST
    case KEYBOARD_LIST
    case EMOJI_LIST
    case EMOJI_ART_LIST
    case OWN_TEXT_LIST
    case KEYBOARD_VIEW
    case KEYBOARD_CLOSE
}

class KeyboardViewController: UIInputViewController {
    // MARK: PROPERTIES
    
  
  
    @IBOutlet weak var tableviewBG: UITableView!
    @IBOutlet var btnR1QtoP: [UIButton]!
    @IBOutlet var btnR21to0: [UIButton]!
    @IBOutlet var btnR3Syb: [UIButton]!
    @IBOutlet var btnR3AtoL: [UIButton]!
    @IBOutlet var btnR4syb: [UIButton]!
    @IBOutlet var btnR5ZtoM: [UIButton]!
    @IBOutlet var nextKeyboardButton: UIButton!
    @IBOutlet weak var ConstentSecoundView: NSLayoutConstraint!
    @IBOutlet weak var btnCapsLock: UIButton!
    @IBOutlet weak var btnCleane: UIButton!
    @IBOutlet weak var btn123: UIButton!
    @IBOutlet weak var btnChangeKeyboard: UIButton!
    @IBOutlet weak var btnSpace: UIButton!
    @IBOutlet weak var viewZtoM: UIView!
    @IBOutlet weak var btnReturn: UIButton!
   
    @IBOutlet weak var ViewR4Sym: UIView!
    @IBOutlet weak var stackR3syb: UIStackView!
    @IBOutlet weak var viewAtoL: UIView!
    @IBOutlet weak var stackR1QtoP: UIStackView!
    @IBOutlet weak var stackR21to0: UIStackView!
    @IBOutlet weak var btnFontList: UIButton!
    @IBOutlet weak var btnKeyboardList: UIButton!
    @IBOutlet weak var btnOwnTextList: UIButton!
    @IBOutlet weak var btnKeyboardClose: UIButton!
    @IBOutlet weak var SecoundView: UIView!
    
    @IBOutlet weak var btnR4SymChange: UIButton!
    // MARK : VARIABLES
    
    var CapslockOn: Bool = false
    fileprivate var Discselect = typeAliasDictionary()
    fileprivate var arrFonts = [typeAliasDictionary]()
    fileprivate var arrKeyboardList = [typeAliasDictionary]()
    fileprivate var selected_Option_Type: Selected_Option = .KEYBOARD_LIST
    var arrSubData : [typeAliasDictionary] = [typeAliasDictionary]()
    var dictDataMain : typeAliasDictionary = typeAliasDictionary()
   
    
    let TableView : UITableView! = nil
    
    override func updateViewConstraints() {
        super.updateViewConstraints()
     // Add custom view sizing constraints here
    }
    override func viewDidLoad() {
        super.viewDidLoad()
  
//    self.nextKeyboardButton.setTitle(NSLocalizedString("Next Keyboard", comment: "Title for 'Next Keyboard' button"), for: [])
//    self.nextKeyboardButton.sizeToFit()
//    self.nextKeyboardButton.translatesAutoresizingMaskIntoConstraints = false
//    
//    self.nextKeyboardButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
//    
//    self.view.addSubview(self.nextKeyboardButton)
//    
//    self.nextKeyboardButton.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
//    self.nextKeyboardButton.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
   }
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
    self.tableviewBG.register(UINib.init(nibName: "KeyboardCell1", bundle: nil), forCellReuseIdentifier: "KeyboardCell")
        
        self.setKeyboard()
        SetBtnProperties(Button: btnR1QtoP)
        SetBtnProperties(Button: btnR21to0)
        SetBtnProperties(Button: btnR3AtoL)
        SetBtnProperties(Button: btnR3Syb)
        SetBtnProperties(Button: btnR4syb)
        SetBtnProperties(Button: btnR5ZtoM)
        
        func getData(strSmall: String,strCapital : String ,strName : String,isFontFree: Bool) -> typeAliasDictionary {
            
            func splitData(str : String) -> [String] {
                var arrData : [String] = [String]()
                for char1 in str { arrData.append("\(char1)") }
                return arrData
            }
            var dict = typeAliasDictionary()
            dict[KEY_FONT_STYLE] = strName as AnyObject
            dict[KEY_FONT_CHARCTERS_SMALL] = splitData(str: strSmall) as AnyObject
            dict[KEY_FONT_CHARCTERS_CAPITAL] = splitData(str: strCapital) as AnyObject
            dict[KEY_IS_FONT_FREE] = isFontFree as AnyObject
            Discselect[KEY_FONT_CHARCTERS_SMALL] = splitData(str: "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣") as AnyObject
            Discselect[KEY_FONT_CHARCTERS_CAPITAL] = splitData(str: "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉") as AnyObject
            Discselect[KEY_FONT_SYMBOLE] = splitData(str: "<>:|^~+-*=") as AnyObject
            Discselect[KEY_FONT_NUBERIC] = splitData(str: "1234567890") as AnyObject
            return dict
        }
        arrFonts.append(getData(strSmall: "₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ", strCapital: "₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ", strName: "Currency Caps", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫", strCapital: "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ", strName: "Double Lines", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷", strCapital: "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ", strName: "Old English", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟", strCapital: "𝕬𝕭𝕮𝕯𝕰𝕱𝕲𝕳𝕴𝕵𝕶𝕷𝕸𝕹𝕺𝕻𝕼𝕽𝕾𝕿𝖀𝖁𝖂𝖃𝖄𝖅", strName: "Bold Old English", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "αвcdєfghíjklmnσpqrstuvwхчz", strCapital: "αв¢∂єfgнιנкℓмиσρqяѕтυνωχуz", strName: "Paranormal", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃", strCapital: "𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩", strName: "Bold Writing", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ΔβCDΣҒGHIJҜLMΠΩPQRSTU∇ᗯXΨZ", strCapital: "ΔβCDΣҒGHIJҜLMΠΩPQRSTU∇ᗯXΨZ", strName: "Capital straight", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "A͚B͚C͚D͚E͚F͚G͚H͚I͚J͚K͚L͚M͚N͚O͚P͚Q͚R͚S͚T͚U͚V͚W͚X͚Y͚Z͚", strCapital: "A͚B͚C͚D͚E͚F͚G͚H͚I͚J͚K͚L͚M͚N͚O͚P͚Q͚R͚S͚T͚U͚V͚W͚X͚Y͚Z͚", strName: "Capital Infinity", isFontFree: true))
        
        
        arrFonts.append(getData(strSmall: "αႦƈԃҽϝɠԋιʝƙʅɱɳσρϙɾʂƚυʋɯxყȥ", strCapital: "ABCDEFGHIJKLMNOPQRSTUVWXYZ", strName: "Simple Writing", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻", strCapital: "𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡", strName: "Simple Italic", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯", strCapital: "𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕", strName: "Bold Italic", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣", strCapital: "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉", strName: "Mono Style", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ", strCapital: "ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ", strName: "Horror Style", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a̶b̶c̶d̶e̶f̶g̶h̶i̶j̶k̶l̶m̶n̶o̶p̶q̶r̶s̶t̶u̶v̶w̶x̶y̶z̶", strCapital: "A̶B̶C̶D̶E̶F̶G̶H̶I̶J̶K̶L̶M̶N̶O̶P̶Q̶R̶S̶T̶U̶V̶W̶X̶Y̶Z̶", strName: "Strike Line", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a̴b̴c̴d̴e̴f̴g̴h̴i̴j̴k̴l̴m̴n̴o̴p̴q̴r̴s̴t̴u̴v̴w̴x̴y̴z̴", strCapital: "A̴B̴C̴D̴E̴F̴G̴H̴I̴J̴K̴L̴M̴N̴O̴P̴Q̴R̴S̴T̴U̴V̴W̴X̴Y̴Z̴", strName: "Strike Tilde", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̷b̷c̷d̷e̷f̷g̷h̷i̷j̷k̷l̷m̷n̷o̷p̷q̷r̷s̷t̷u̷v̷w̷x̷y̷z̷", strCapital: "A̷B̷C̷D̷E̷F̷G̷H̷I̷J̷K̷L̷M̷N̷O̷P̷Q̷R̷S̷T̷U̷V̷W̷X̷Y̷Z̷", strName: "Strike Slash", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̲b̲c̲d̲e̲f̲g̲h̲i̲j̲k̲l̲m̲n̲o̲p̲q̲r̲s̲t̲u̲v̲w̲x̲y̲z̲", strCapital: "A̲B̲C̲D̲E̲F̲G̲H̲I̲J̲K̲L̲M̲N̲O̲P̲Q̲R̲S̲T̲U̲V̲W̲X̲Y̲Z̲", strName: "Single Underline", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭Yᘔ", strCapital: "ᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭Yᘔ", strName: "Hollow Style", isFontFree: true))
        
        var dict = typeAliasDictionary()
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_1" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.black as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.white as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_2" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_3" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.white as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_4" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_5" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_6" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_7" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_8" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_9" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.red as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.red as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_10" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_11" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_12" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_13" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.black.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_14" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        func GetData(strSubData: String,IsTextArtLock : Bool) -> typeAliasDictionary {
            var dict = typeAliasDictionary()
            dict[KEY_TEXT_ART_SUB_DATA] = strSubData as AnyObject
            dict[KEY_IS_TEXT_ART_LOCK] = IsTextArtLock as AnyObject
            return dict
        }
        
        //1
        var strData : String =
            "GOOD 😊 MORNING!\n" +
                "☁✨✨☁✨✨☁\n" +
                "✨✨✨✨✨✨✨\n" +
                "✨✨✨✨✨✨✨\n" +
                "☁✨✨✨✨✨☁\n" +
                "☁☁✨✨✨☁☁\n" +
        "☁☁☁✨☁☁☁"
        var dictData : typeAliasDictionary = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "🛁🛁😍🛁🛁🛁😍🛁🛁\n" +
            "🛁😍🛁😍🛁😍🛁😍🛁\n" +
            "🛁😍🛁🛁😍🛁🛁😍🛁\n" +
            "🛁😍🛁🛁🛁🛁🛁😍🛁\n" +
            "🛁🛁😍🛁🛁🛁😍🛁🛁\n" +
            "🛁🛁🛁😍🛁😍🛁🛁🛁\n" +
            "🛁🛁🛁🛁😍🛁🛁🛁🛁\n" +
            "🛁🛁🛁🛁🛁🛁🛁🛁🛁\n" +
        "🛁 GOOD MORNING 🛁"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "🌸🌸🌸🌸🌸🌸\n" +
            "🌉🌉🌉🌉🌉\n" +
            "*Good*   ☺️☺️☺️\n" +
            "*Morning*\n" +
            "☺️☺️☺️  *Friend* ☺️☺️☺️\n" +
            "🌉🌉🌉🌉🌉\n" +
        "🌸🌸🌸🌸🌸🌸"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "🌄Good morning!🌄\n" +
            "💛------😴------💛\n" +
            "☀️---🍳🎽☕️----☀️\n" +
            "☀️------👖------☀️\n" +
            "💛-----👡👡-----💛\n" +
        "🌄 💛 ☀️ ☀️ ☀️ 💛🌄"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "😈😈😈😈😈😈😈😈😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😜😜😈😈😈😜😜😈\n" +
            "😈😈😈😈😈😈😈😈😈\n" +
            "😈😈😈😈😈😈😈😈😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😈😈😜😜😜😈😈😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😜😜😜😜😜😜😜😈\n" +
            "😈😈😈😈😈😈😈😈😈\n" +
        "GOOD        MORNING"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Good Morning Wishes" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//       self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData  =
            "🌑🌒🌓🌔🌕🌖🌗🌘🌑\n" +
            "🌜🌛🌜🌛🌜🌛🌜🌛\n" +
            "🌑🌘🌗🌖🌕🌔🌓🌒🌑\n" +
            "⭐⭐GOOD NIGHT⭐⭐\n" +
            "🌑🌒🌓🌔🌕🌖🌗🌘🌑\n" +
            "🌜🌛🌜🌛🌜🌛🌜🌛\n" +
        "🌑🌘🌗🌖🌕🌔🌓🌒🌑"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "     💕🍃🌹🍃💕\n" +
            "💕.•°``°•.¸.•°``°•.💕\n" +
            "💕(     GOOD       ) 💕\n" +
            "💕`•.¸   💗   ¸.•` 💕\n" +
            "    💕° •.¸¸.•° 💕\n" +
            "        💕💕\n" +
            "        💕     💕🍃🌹🍃💕\n" +
            "           💕.•°``°•.¸.•°``°•.💕\n" +
            "           💕(     NIGHT        ) 💕\n" +
            "           💕`•.¸   💗   ¸.•` 💕\n" +
            "                💕° •.¸¸.•° 💕\n" +
            "                   💕💕\n" +
        "                    💕"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "😌{ It's time to sleep! )\n" +
            "    ☁☁☁☁☁🌟☁🌟\n" +
            " ☁💜💜☁💜💜🌟☁\n" +
            "💜💜💜💜💜🌟💜🌟\n" +
            "💜💜💜💜🌟💜💜☁\n" +
            "💜💜💜💜💜💜💜☁\n" +
            "☁💜💜💜💜💜☁☁\n" +
            "☁🌟💜💜💜☁☁🌙\n" +
            "🌟☁☁💜☁☁☁🐑\n" +
            "🌹🌹🌹🌹🌹🌹🌹🌹\n" +
        "( Goooood night ♫ }😪"
        
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "💋💋💋💋💋☁\n" +
            "💋💋💋💋💋💋\n" +
            "💋💋☁☁💋💋\n" +
            "💋💋☁☁💋☁\n" +
            "💋💋💋💋💋☁\n" +
            "💋💋☁☁💋💋\n" +
            "💋💋☁☁💋💋\n" +
            "💋💋💋💋💋💋\n" +
            "💋💋💋💋💋☁\n" +
            "☁☁☁☁☁☁\n" +
            "👋👋☁☁👋👋\n" +
            "👋👋☁☁👋👋\n" +
            "👋👋☁☁👋👋\n" +
            "👋👋👋👋👋👋\n" +
            "☁👋👋👋👋☁\n" +
            "☁☁👋👋☁☁\n" +
            "☁☁👋👋☁☁\n" +
            "☁☁👋👋☁☁\n" +
            "☁☁☁☁☁☁\n" +
            "💋💋💋💋💋💋\n" +
            "💋💋💋💋💋💋\n" +
            "💋💋☁☁☁☁\n" +
            "💋💋💋💋💋☁\n" +
            "💋💋💋💋💋☁\n" +
            "💋💋☁☁☁☁\n" +
            "💋💋💋💋💋💋\n" +
            "💋💋💋💋💋💋\n" +
        "GOOD   NIGHT"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "✨✨🌟✨🌒🌟\n" +
            "✨✨⭐✨✨⭐\n" +
            "☁☁☁☁☁☁\n" +
            "☁  ⛅  ☁ ☁\n" +
            "☁ ☁ ☁  🚀 ☁\n" +
            "☁☁   ⚡   ☁\n" +
            "☁☁  ⚡ ☁  ☁\n" +
            "☁  ⚡ ☁  ☁\n" +
            " ☁⚡☁ ☁  ☁\n" +
            " ☁☁☁☁☁☁\n" +
            "🌴    🌴   🌴\n" +
            "🌴    🌴   🌴   🌴\n" +
            "GOOD   NIGHT\n" +
        "SWEET    DREAMS"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Good Night Wishes" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        
        //1
        strData  =
            
            "-----🎂　 ※　˚　 。  🍰\n" +
            "--------🔥🔥🔥\n" +
            "---------│--│--│ ∴ 🍅\n" +
            "-✨--┎────┒\n" +
            "------┃🍓🍓🍓┃+ ˚\n" +
            "----┎┸────┸┒\n" +
            "----┃~ⓗⓐⓟⓟⓨ~┃🎵\n" +
            "--┎┸──────┸┒\n" +
            "--┃ⓑⓘⓡⓣⓗⓓⓐⓨ┃*\n" +
            "--┸────────┸\n" +
            "       , , , , , , ,\n" +
            "       | | | | | | |\n" +
            "{🎂_•_🎂_•_🎂}\n" +
            "{🎂_•_🎂_•_🎂}\n" +
        "{🎂_•_🎂_•_🎂}"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData = "\n" +
            "------🔥 🔥 🔥\n" +
            "------💗 💗 💗\n" +
            "------💗 💗 💗\n" +
            "🎂🎂🎂🎂🎂🎂🎂\n" +
            "🎉🎈🎉🎈🎉🎈🎉\n" +
            "HAPPY 💝 B-DAY\n" +
            "🎉🎈🎉🎈🎉🎈🎉\n" +
        "🎂🎂🎂🎂🎂🎂🎂"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "  ✨🍺🍺🍺🍺🍺✨\n" +
            "  🍺✨✨🎩✨✨🍺\n" +
            "  🍺🌟🎁👦🎁🌟🍺\n" +
            "  🍺🌟🎁💼🎁🌟🍺\n" +
            "  🍺🌟🎁🔥🎁🌟🍺\n" +
            "🍺Happy birthday🍺\n" +
            "✨ 🍺🍺🍺🍺🍺✨\n" +
        "☀☀☀☀☀☀☀☀"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "🌺happy birthday!🌺\n" +
            " 🌷🌷🌷🌷🌷🌷🌷\n" +
            "--🏠🏠🏠🏠🏠🏠--\n" +
            "---🙆🙆🙆🙆🙆---\n" +
            "----🎉🎉🎉🎉----\n" +
            "-----🎊🎊🎊-----\n" +
            "-----🎈🎈🎈-----\n" +
            "------🎁🎐------\n" +
        "-------🐶-------"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "--🎉🎉🎉🎉🎉🎉🎉\n" +
            "-------🎈  🎈  🎈\n" +
            "---🎈🎊🎉🎂🎉🎊🎈\n" +
            "-✨🎉🎁🎊🎁🎉✨\n" +
            "--✨🌟⭐✨⭐⭐✨\n" +
            "----✨🌟⭐🌟😖\n" +
            "-------😖🌟😖\n" +
            "---------🌟\n" +
            "\n" +
            "----------🔥-------\n" +
            "-------💗❤💗-----\n" +
            "------💗❤❤💗--\n" +
            "-----H 🍓🍓🍓 B✨\n" +
            "----A🎂🎂🎂🎂 I 💓\n" +
            "---P @👑@👑@ R D\n" +
            "--P 🍰🍰🍰🍰🍰 T A\n" +
        "-Y @====@====@ H Y"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Birthday Wishes" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData  =
            "----👑\n" +
            "----😎\n" +
            "-✌👕✌\n" +
            "----👖\n" +
        "---👟👟"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "🐎💨\n" +
            "🐑💨\n" +
            "🐘💨\n" +
            "🐫💨\n" +
            "🐳💨\n" +
            "🐒💨\n" +
            "🐩💨\n" +
            "🐈💨\n" +
            "🐆💨\n" +
            "🐓💨\n" +
            "🐕💨\n" +
            "🐖💨\n" +
            "🐁💨\n" +
        "🐂💨💨💨"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "🔋100% 😃\n" +
            "🔋90% 😆\n" +
            "🔋80% 😁\n" +
            "🔋70% 😏\n" +
            "🔋60% 😅\n" +
            "🔋50% 😬\n" +
            "🔋40% 😐\n" +
            "🔋30% 😥\n" +
            "🔋20% 😧\n" +
            "🔋10 % 😫\n" +
        "🔋3% 😱🔌🏃💨💨"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "🎀 💓 🌟✨🌟 💓 🎀\n" +
            "💓   Everybody   💓\n" +
            "🌟   🍥poops!🍥  🌟\n" +
            "✨       👸      ✨\n" +
            "🌟  ✌️👚        🌟\n" +
            "💓       🚽💨    💓\n" +
        "🎀 💓 🌟💩🌟 💓 🎀"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
        "🚽       🏃   🏃 ❗️ 🚶  🚶"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Funny Emojis" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData = "\n" +
            "🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹\n" +
            "🌹------😢😷😢💨------🌹\n" +
            "🌹---💝💉🍵💊💐💝---🌹\n" +
            "🌹-----Get Well Soon!----🌹\n" +
        "🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "💚🍀🍀🍀🍀🍀🍀🍀\n" +
            "🍀╔╗╔╗╔╗╦╗🍀\n" +
            "🍀║╦║║║║║║🍀\n" +
            "🍀╚╝╚╝╚╝╩╝🍀\n" +
            "🍀・・・・ ⓁⓊⒸⓀ 🍀\n" +
        "🍀🍀🍀🍀🍀 to you💚"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            
            "📲😳 I'm busy!💫\n" +
            "☝️👕\n" +
        "---🚽💩💩💩💩"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "⁣☁  🌧 ☁ 🌧 ☁  ☁\n" +
            "           💦     💦   👦💦\n" +
            "👦   💦        💦\n" +
            "    💦⁣  👨🏿   💦    👲\n" +
            "  👳           💦\n" +
            "                    ☔\n" +
        "                👩"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "🚽 = 2 Minutes \n" +
            "🚽 + 📱 = 5 Minutes \n" +
            "🚽 + 📱 + ⁣📶 = 10 Minutes \n" +
        "🚽 + 📱 + 📶 + 🔋 = Infinite"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Messages" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData = "\n" +
            "☀☀☀\n" +
            "💛💛💛\n" +
            "---👧\n" +
            "☕👚👌\n" +
            "---👖\n" +
            "---👡👡\n" +
            "💛💛💛\n" +
        "☀☀☀"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            
            "📔📚             📚\n" +
            "📓📚📖  😫  📚📚📓\n" +
            "📕📚📚  📝  📗💻📘\n" +
            "📖📖📖📖📖📖📖📖 \n" +
            "Doing my #Homework! \n" +
        "✏️📝✏️📝✏️📝✏️📝"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "⚪ Single \n" +
            "⚪ In a relashionship \n" +
        "🔘 Sleeping"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "------🍥\n" +
            "---🍡🍥🍓\n" +
            "---🍥🍥🍥\n" +
            "--🍥🍓🍥🍥\n" +
            "🍥🍥🍥🍥🍥\n" +
            "🍞🍞🍞🍞🍞\n" +
            "🍞🍞🍞🍞🍞\n" +
            "--🍞🍞🍞🍞\n" +
            "---🍞🍞🍞\n" +
        "---🍞🍞🍞"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "---♨♨♨\n" +
            "⬜⬜⬜⬜⬜🍡\n" +
            "-⬜⬜⬜⬜    🎐\n" +
            "-⬜coffee⬜  🎐\n" +
            "-⬜⬜⬜⬜💕\n" +
        "--⬜⬜⬜"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Mood & Food" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData  =
            "💢👄👄💢👄👄💢\n" +
            "👄💢💢👄💢💢👄\n" +
            "👄💢💢💢💢💢👄\n" +
            "💢👄💢💢💢👄💢\n" +
            "💢💢👄💢👄💢💢\n" +
        "💢💢💢👄💢💢💢"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "---😍😍        😍😍----\n" +
            " 😍💰💰😍 💰💰😍\n" +
            "😍💳💶💰💰💳💶😍\n" +
            "😍💰💰💳💰💰😍\n" +
            " ---😍💶💰 💰😍------\n" +
            " ----- 😍💶 😍--------\n" +
        "----------😍----------"
        
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "❤🔫🔫❤🔫🔫❤\n" +
            "🔫🔫🔫🔫🔫🔫🔫\n" +
            "🔫🔫🔫🔫🔫🔫🔫\n" +
            "❤🔫🔫🔫🔫🔫❤\n" +
            "❤❤🔫🔫🔫❤❤\n" +
        "❤❤❤🔫❤❤❤"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "💍💍💍💍💍💍💍\n" +
            "💍💜💜💍💜💜💍\n" +
            "💜♈♉💜♋♌💜\n" +
            "💜♎♏♐♑♒💜\n" +
            "💍💜♐♑♈💜💍\n" +
            "💍💍💜♉💜💍💍\n" +
            "💍💍💍💜💍💍💍\n" +
        "💍💍💍💍💍💍💍"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "🔱🔱🔱🔱🔱🔱🔱\n" +
            "🔱🍇🍇🔱🍇🍇🔱\n" +
            "🍇🌸🌸🍇🌸🌸🍇\n" +
            "🍇 MISS 🌸 YOU 🍇\n" +
            "🍇🌸🌸🌸🌸🌸🍇\n" +
            "🔱🍇🌸🌸🌸🍇🔱\n" +
            "🔱🔱🍇🌸🍇🔱🔱\n" +
        "🔱🔱🔱🍇🔱🔱🔱"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //6
        strData =
            "----------🌹🌹🌹☁\n" +
            "------☁🌹🌹🌹🌹🌹\n" +
            "-------🌹🌹😍😍🌹🌹\n" +
            "-----🌹🌹😍😍😍🌹🌹\n" +
            "-------🌹🌹😍😍🌹🌹\n" +
            "--------🌹🌹🌹🌹🌹\n" +
            "-----------🌹🌹🌹\n" +
            "---------🌴\n" +
            "---------🌴\n" +
            "---🍂      🌴    🍂\n" +
            "---🍂🍂   🌴   🍂🍂\n" +
            "---🍂🍂 🌴  🍂🍂\n" +
            "---🍂🍂🍂🌴🍂🍂🍂\n" +
        "---💚💚💚🌴💚💚💚"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //7
        strData =
            "🌴🍃🌺🌺🍃🌴\n" +
            "💛🌻🌻🌻🌻💚\n" +
            "🌻🌻   😍  🌻🌻\n" +
            "🌻 Love YOU 🌻\n" +
            "🌻🌻   🌹  🌻🌻\n" +
            "💚🌻🌻🌻🌻💛\n" +
        "🌴🍃🌺🌺🍃🌴"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //8
        strData =
            "🌟🌟🌟🌟🌟🌟\n" +
            "🌸🌸👰👦🌸🌸\n" +
            "🌸🌸👚👕🌸🌸\n" +
            "🌸🌸💭👖🌸🌸\n" +
        "🌟🌟🌟🌟🌟🌟"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        
//        dictDataMain[KEY_TEXT_ART_DATA_TITILE] = "Love Emojis" as AnyObject
//        dictDataMain[KEY_TEXT_ART_DATA] = arrSubData as AnyObject
//        self.arrTextArtData.append(dictDataMain)
//        arrSubData = [typeAliasDictionary]()
        
        //1
        strData  =
            "--------------🌟-----------\n" +
            "------------🎄🎄----------\n" +
            "-----------🎄💝🎄--------\n" +
            "---------🎄🎅🎅 🎄-------\n" +
            "--------🎄👢📱🏈 🎄------\n" +
            "-------🎄🎺🎿🎸💄🎄-----\n" +
            "-----🎄🎅🎅🎅🎅🎅 🎄----\n" +
            "----🎄👗👒🚲💐🐶⚽ 🎄---\n" +
            "---🎄🎥🐱🎷👠💝📷💽 🎄--\n" +
        "-🎁🎁🎁🎁🎁🎁🎁🎁🎁🎁-"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //2
        strData =
            "---🎅 🎁 🎄   ❄ ⛄ 🎅---\n" +
            "⛄　　      🎅🎁    　   🎄\n" +
            "-💚　 　　　🎄 　 　 🎁-\n" +
            "--❤　    Merry           ❄--\n" +
            "-----🎁    Christmas!⛄-----\n" +
            "--------❄　        🎅-------\n" +
            "----------🎄　  💚----------\n" +
        "-------------⛄-------------"
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //3
        strData =
            "   🌟。❤。😉。🍀\n" +
            "   。🎁 。🎉。🌟\n" +
            "   ✨。＼｜／。🌺\n" +
            "    🎉happy\n" +
            "  🎈new year🎈\n" +
            "   🍸 2019!! 🍻\n" +
            "  💜。／｜＼。💎\n" +
            "   。🍀。 🌹。🎉。\n" +
        "   🌟。 😊。 🎶 💗"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //4
        strData =
            "*-ⒽⒶⓅⓅⓎ-*\n" +
            "✨🌹🌹🌹✨\n" +
            "🌹✨✨✨🌹\n" +
            "🌹🎁🎩🎁🌹\n" +
            "🌹🎁👨🎁🌹\n" +
            "🌹🎁👔🎁🌹\n" +
            "🌹🎁👟🎁🌹\n" +
            "🌹✨✨✨🌹\n" +
            "✨🌹🌹🌹✨\n" +
            "ⒻⒶⓉⒽⒺⓇ'Ⓢ\n" +
        "💜~ⒹⒶⓎ~💜"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //5
        strData =
            "----💗💓          💓💗-----\n" +
            "💗💓   💗💓💓   💓💗\n" +
            "💓💗   💓💓💗   💗💓\n" +
            " 💓💗    Mommy   💓💗\n" +
            "--💓💗  💓💓  💓💗--\n" +
            "  ---💓💗  💓  💗💓---\n" +
            "   -----💓💓💓-----\n" +
            "    --------💓---------\n" +
        "Happy Mother's Day"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //6
        strData =
            "😄😊😃☺😉😍😘😳\n" +
            "♥*New*YearBegins♥\n" +
            "👦👧👩👨👶👵👴👱\n" +
            "💗~GODbless'YOU'💗\n" +
            "👲👳👮👼👸🙆🙇👽\n" +
            "💛&GoodLuckToU~💛\n" +
            "🐶🐹🐰🐯🐻🐷🐮🐵\n" +
            "💜💜💜💜💜💜💜\n" +
        "😚😁😌😜😝🎅🎃🎶"
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //7
        strData =
            "❄️❄️❄️❄️❄️\n" +
            "❄️❄️👲❄️❄️\n" +
            "❄️❄️🎽✌️❄️\n" +
            "❄️❄️👖❄️❄️\n" +
            "❄️❄️🎿❄️❄️\n" +
            "❄️🔴️🔴️❄️❄️\n" +
            "🔴️WINNER🔴️\n" +
        "🔴️🔴️🔴️🔴️🔴️"
        
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
        //8
        strData =
            "🍸🍸🍸🍸🍸🍸🍸🍸🍸🍸\n" +
            "🍸🍸Let's P-A-R-T-Y!🍸🍸\n" +
        "🍸🍸🍸🍸🍸🍸🍸🍸🍸🍸"
        
        
        dictData = GetData(strSubData: strData, IsTextArtLock: true)
        arrSubData.append(dictData)
        
      TableView.reloadData()
   }
    var keyboardView : UIView!
    
    func setKeyboard()  {
        if keyboardView == nil {
            let keyboardNib = UINib(nibName: "NewCustomKeyboardDemo", bundle: nil)
            keyboardView = (keyboardNib.instantiate(withOwner: self, options: nil).first as! UIView)
            view.frame = keyboardView.frame
            ConstentSecoundView.constant = view.frame.height
        }
        view.addSubview(keyboardView!)
    }
    func SetBtnProperties(Button:[UIButton]) {
        for btn in Button {
            btn.frame = CGRect.zero
            btn.layer.borderWidth = 2
            btn.layer.borderColor = UIColor.yellow.cgColor
            btn.layer.backgroundColor = UIColor.green.cgColor
            btn.tintColor = UIColor.blue
            btn.layer.cornerRadius = 15
      }
    }
    override func textWillChange(_ textInput: UITextInput?) {
        // The app is about to change the document's contents. Perform any preparation here.
    }
    
    override func textDidChange(_ textInput: UITextInput?) {
        // The app has just changed the document's contents, the document context has been updated.
        
        var textColor: UIColor
        let proxy = self.textDocumentProxy
        if proxy.keyboardAppearance == UIKeyboardAppearance.dark {
            textColor = UIColor.white
        } else {
            textColor = UIColor.black
        }
       //  self.nextKeyboardButton.setTitleColor(textColor, for: [])
    }
    @IBAction func btnOtheraction(_ sender: UIButton) {
    
        switch sender.tag {
        case 1:
            btn123.isSelected = !btn123.isSelected
            if btn123.isSelected{
                stackR1QtoP.isHidden = true
                stackR21to0.isHidden = false
                viewAtoL.isHidden = true
                stackR3syb.isHidden = false
                viewZtoM.isHidden = true
                ViewR4Sym.isHidden = false
                btn123.setTitle("ABC", for: .normal)
                
            }else{
                stackR1QtoP.isHidden = false
                stackR21to0.isHidden = true
                viewAtoL.isHidden = false
                stackR3syb.isHidden = true
                viewZtoM.isHidden = false
                ViewR4Sym.isHidden = true
                btn123.setTitle("123", for: .normal)
            }
            break
        case 2:
            btnCapsLock.isSelected = !btnCapsLock.isSelected
            let arrFontText : [String] = Discselect[btnCapsLock.isSelected ? KEY_FONT_CHARCTERS_SMALL : KEY_FONT_CHARCTERS_CAPITAL] as! [String]
            for btn in btnR1QtoP{btn.setTitle("\(arrFontText[btn.tag])", for: .normal)}
            for btn in btnR3AtoL{btn.setTitle("\(arrFontText[btn.tag])", for: .normal)}
            for btn in btnR5ZtoM{btn.setTitle("\(arrFontText[btn.tag])", for: .normal)}
            view.layoutIfNeeded()
           break
        case 3:
            
             advanceToNextInputMode()
            break
        case 4:
            
             (textDocumentProxy as UIKeyInput).insertText(" ")
            break
        case 5:
           
             (textDocumentProxy as UIKeyInput).deleteBackward()
            break
        case 6:
            
             (textDocumentProxy as UIKeyInput).insertText("\n")
            break
     default:
            break
        }
    }
    
    @IBAction func btnR1Qtop(_ sender: UIButton) {
        (textDocumentProxy as UIKeyInput).insertText((sender.titleLabel?.text)!)
    }
    
    
    @IBAction func btnR4sym(_ sender: UIButton) {
        btnR4SymChange.isSelected = !btnR4SymChange.isSelected
     let arrFontText : [String] = Discselect[btnR4SymChange.isSelected ? KEY_FONT_SYMBOLE : KEY_FONT_NUBERIC] as! [String]
            for btn in btnR21to0{btn.setTitle("\(arrFontText[btn.tag])", for: .normal)}
 }
    
}
extension KeyboardViewController:UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch selected_Option_Type {
        case .FONT_LIST:
            return arrFonts.count
        case .KEYBOARD_LIST:
            return arrKeyboardList.count
       default:
            return arrSubData.count
        }
     }
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        TableView.register(UINib.init(nibName: "FontCell", bundle: nil), forCellReuseIdentifier: "FontCell")
    let tableViewCell = UITableViewCell()
    
    switch selected_Option_Type {
    case .FONT_LIST:
        TableView.register(UITableViewCell.self, forCellReuseIdentifier: "FontCell")
        let cell  = TableView.dequeueReusableCell(withIdentifier: "FontCell", for: indexPath)
        let disc : typeAliasDictionary = arrFonts[indexPath.row]
        cell.textLabel?.text = "\(disc[KEY_FONT_STYLE]!)"
        return cell
    case .KEYBOARD_LIST:
     
//        TableView.register(KeyboardCell.self, forCellReuseIdentifier: "KeyboardCell")
        let cell : KeyboardCell = tableView.dequeueReusableCell(withIdentifier: "KeyboardCell", for: indexPath) as! KeyboardCell
        let disc : typeAliasDictionary = arrKeyboardList[indexPath.item]
      //  cell.textLabel?.text = "\(disc[KEY_DESIGN_NAME]!)"
       cell.imageView?.image = (disc[KEY_BG_IMAGE]as! UIImage)
        return cell
     case .OWN_TEXT_LIST:
        TableView.register(UITableViewCell.self, forCellReuseIdentifier: "OwnText")
        let cell = TableView.dequeueReusableCell(withIdentifier: "OwnText", for: indexPath)
        let disc : typeAliasDictionary = arrSubData[indexPath.row]
        cell.textLabel?.text = "\(disc[KEY_TEXT_ART_SUB_DATA]!)"
        return cell
    case .KEYBOARD_CLOSE:
           setKeyboard()
        break
    default:
        break
    }
    return tableViewCell
     }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch selected_Option_Type {
        case .FONT_LIST:
            return 60.0
        case .KEYBOARD_LIST:
            return 210.0
        default:
             return UITableView.automaticDimension
        }
   }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch selected_Option_Type {
      case .OWN_TEXT_LIST:
        let disc : typeAliasDictionary = arrSubData[indexPath.row]
        
            let select = "\(disc[KEY_TEXT_ART_SUB_DATA]!)"
           (textDocumentProxy as UIKeyInput).insertText(select)
            
            break
        default:
            break
        }
    }
   func TableViewBG()  {
        TableView.frame = CGRect(x: 0, y: 40, width: self.view.frame.size.width, height: 283)
        TableView.delegate = self
        TableView.dataSource = self
        self.view.addSubview(TableView)
    }
    @IBAction func btnUpperAction(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            selected_Option_Type = .FONT_LIST
            btnFontList.isSelected = !btnFontList.isSelected
            if btnFontList.isSelected{
                SecoundView.isHidden = true
                TableView.isHidden = false
                TableViewBG()
            }else{
                SecoundView.isHidden = false
               TableView.isHidden = true
            }
            TableView.reloadData()
           break
        case 2:
               selected_Option_Type = .KEYBOARD_LIST
               btnKeyboardList.isSelected = !btnKeyboardList.isSelected
               if btnKeyboardList.isSelected{
                SecoundView.isHidden = true
                TableView.isHidden = false
                TableViewBG()
               }else{
                SecoundView.isHidden = false
                TableView.isHidden = true
               }
                TableView.reloadData()
            break
        case 3:
            selected_Option_Type = .OWN_TEXT_LIST
            btnOwnTextList.isSelected = !btnOwnTextList.isSelected
            if btnOwnTextList.isSelected{
                SecoundView.isHidden = true
                TableView.isHidden = false
                TableViewBG()
            }else{
                SecoundView.isHidden = false
                TableView.isHidden = true
            }
             TableView.reloadData()
            break
        case 4:
            selected_Option_Type = .KEYBOARD_CLOSE
           
            break
        default:
            break
        }
    }
    
}
